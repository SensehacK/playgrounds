'''
Created on Mar 15, 2017

@author: kautilya.save
'''
'''
This class represents a product
'''
class Food:
    def __init__(self):
        self.__product_id=None
        self.__restaurant_name=None
        self.__registered_user=None
        self.__category=None
