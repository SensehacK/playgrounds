'''
Created on Mar 17, 2017

@author: gaurav.sainger
'''
def empty_validation(input_data):
    a = input("username:")
    if (len(a) == 0):
        print("Username cannot be empty")
        
empty_validation("rohita")
