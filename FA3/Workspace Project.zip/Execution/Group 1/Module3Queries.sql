-- Drop
Drop TABLE FoodItem cascade constraints;


CREATE TABLE FoodItem (
  Id          	INTEGER PRIMARY KEY,
  FoodName    	VARCHAR2(40)  ,
  Food_Type  CHAR(2)  CHECK(Food_Type IN ('V','NV')),
  Price      	DECIMAL(9,2)  ,
  Availability  CHAR(2)  CHECK(Availability IN ('A','NA')),
  Restaurant_Name VARCHAR2(40)  ,
  Category_Name VARCHAR2(40) 
);

-- Data for FoodItem table  --
------------------------------


INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (1,'Chicken Fry' , 'NV',500,'A' ,'KAMAT HOTEL' , 'Chicken');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (2,'Fish' , 'NV',900,'A' ,'MODERN RESTAURANT' , 'Fish' );
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (3,'Mutton' , 'NV',250,'A' ,'BIRYANI HOUSE', 'Mutton');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (4,'Sea Food' , 'NV',300,'A' ,'SUKH SAGAR' , 'Sea Food');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (5,'Egg' , 'NV',400,'A' ,'KAMAT HOTEL' , 'Chicken');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (6,'Vegetarian', 'NV',350,'A' ,'KAMAT HOTEL' , 'Vegetarian');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (7,'Starters', 'V',507,'A' ,'MODERN RESTAURANT' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (8,'Paneer', 'V',300,'A' ,'KAMAT HOTEL' , 'Vegetarian');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (9,'Green Peas', 'V',180,'A' ,'KAMAT HOTEL' , 'Vegetarian');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (10,'Bhindi Masala', 'V',280,'NA' ,'KAMAT HOTEL' , 'Vegetarian');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (11,'Chicken Tawa' , 'NV',700,'A' ,'SUKH SAGAR' , 'Chicken');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (12,'Bhindi Masala', 'V',280,'A' ,'KAMAT HOTEL' , 'Egg');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (13,'Promphet Masala', 'NV',780,'A' ,'KAMAT HOTEL' , 'Sea Food');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (14,'Lamb Masala', 'NV',880,'A' ,'KAMAT HOTEL' , 'Mutton');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (15,'Masala Papad', 'V',80,'A' ,'KAMAT HOTEL' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (16,'Manchurian Dry', 'V',120,'NA' ,'KAMAT HOTEL' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (17,'Fish' , 'NV',900,'A' ,'MODERN RESTAURANT' , 'Fish' );
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (18,'Bhindi Do Pyaza', 'V',280,'NA' ,'KAMAT HOTEL' , 'Egg');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (19,'Mackarel Masala', 'NV',780,'A' ,'KAMAT HOTEL' , 'Sea Food');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (20,'Lamb Roast', 'NV',880,'A' ,'KAMAT HOTEL' , 'Mutton');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (21,'Chineese Bhel', 'V',50,'A' ,'KAMAT HOTEL' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (22,'Gobi Manchurian', 'V',120,'A' ,'KAMAT HOTEL' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (23,'Bombay Duck' , 'NV',300,'A' ,'SUKH SAGAR' , 'Fish' );
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (24,'Fish Curry' , 'NV',800,'A' ,'MODERN RESTAURANT' , 'Fish' );
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (25,'Mutton Gravy' , 'NV',550,'A' ,'BIRYANI HOUSE', 'Mutton');
commit;



INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (26,'Papad', 'V',180,'A' ,'KAMAT HOTEL' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (27,'Masala', 'V',60,'A' ,'KAMAT HOTEL' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (28,'Papad', 'V',80,'NA' ,'KAMAT' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (29,'Bombay Duck', 'V',280,'A' ,'KAMAT' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (30,'Raitha', 'V',40,'A' ,'KAMAT' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (31,'Chineese Bhel', 'V',80,'A' ,'MODERN' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (32,'FishTai', 'NV',80,'A' ,'KAMAT' , 'Fish');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (33,'Masala', 'V',80,'A' ,'MODERN' , 'Chicken');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (34,'Chicken', 'NV',80,'A' ,'KAMAT' , 'Chicken');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (35,'Egg', 'NV',80,'A' ,'KAMAT' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (36,'Papad', 'V',80,'A' ,'MODERN' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (37,'Bombay Duck', 'NV',80,'A' ,'MODERN' , 'Fish');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (38,'Egg', 'NV',80,'A' ,'MODERN' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (39,'Bhel', 'V',80,'A' ,'MODERN' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (40,'Mutton', 'V',80,'A' ,'MODERN' , 'Mutton');



commit;



INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (41,'Fish Papad', 'V',180,'A' ,'PARIKARMA' , 'Fish');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (42,'Chicken Masala', 'V',60,'A' ,'PARIKARMA' , 'Chicken');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (43,'Papad', 'V',80,'A' ,'ARDOR' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (44,'Bombay Duck', 'V',280,'A' ,'ZEN' , 'Sea Food');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (45,'Raitha', 'V',40,'A' ,'PARIKARMA' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (46,'Chineese Bhel', 'V',80,'NA' ,'MODERN' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (47,'FishTai', 'NV',80,'A' ,'AMBER' , 'Fish');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (48,'Masala', 'V',80,'A' ,'ARDOR' , 'Chicken');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (49,'Chicken Kurma', 'NV',80,'A' ,'AMBER' , 'Chicken');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (50,'Egg', 'NV',80,'A' ,'KAMAT' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (51,'Papad', 'V',80,'A' ,'RABBIT' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (52,'Bombay Duck', 'NV',80,'A' ,'ARDOR' , 'Fish');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (53,'Egg', 'NV',80,'A' ,'BARBEQUE' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (54,'Bhel', 'V',80,'A' ,'ZEN' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (55,'Mutton', 'V',80,'A' ,'MODERN' , 'Mutton');



INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (56,'Vegetarian', 'NV',350,'A' ,'ZEN' , 'Vegetarian');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (57,'Starters', 'V',507,'A' ,'MODERN RESTAURANT' , 'Vegetarian');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (58,'Paneer', 'V',300,'A' ,'PARIKARMA' , 'Vegetarian');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (59,'Green Peas', 'V',180,'A' ,'AMBER' , 'Vegetarian');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (60,'Bhindi Masala', 'V',280,'A' ,'DILLI DARBAR' , 'Vegetarian');


commit;


INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (61,'Chineese Bhel', 'V',80,'A' ,'BARBEQUE' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (62,'FishChilly', 'NV',80,'A' ,'AMBER' , 'Fish');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (63,'Masala', 'V',80,'A' ,'BARBEQUE' , 'Chicken');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (64,'Chicken Kurma', 'NV',80,'A' ,'AMBER' , 'Chicken');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (65,'Egg', 'NV',80,'A' ,'AMBER' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (66,'Papad', 'V',80,'A' ,'BARBEQUE' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (67,'Bombay Duck', 'NV',80,'A' ,'BARBEQUE' , 'Fish');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (68,'Egg', 'NV',80,'A' ,'BARBEQUE' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (69,'Bhel', 'V',80,'A' ,'BARBEQUE' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (70,'Mutton', 'V',80,'A' ,'BARBEQUE' , 'Mutton');





INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (71,'Chineese Bhel', 'V',80,'A' ,'ANNA' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (72,'Fish Grill', 'NV',80,'A' ,'AMBER' , 'Fish');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (73,'Masala', 'V',80,'A' ,'ANNA' , 'Chicken');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (74,'Chicken Kofta', 'NV',80,'A' ,'AMBER' , 'Chicken');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (75,'Egg Toast', 'NV',80,'A' ,'AMBER' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (77,'Papad', 'V',80,'A' ,'ANNA' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (77,'Bombay Duck', 'NV',80,'A' ,'ANNA' , 'Fish');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (78,'Egg', 'NV',80,'A' ,'ANNA' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (79,'Bhel', 'V',80,'A' ,'ANNA' , 'Starters');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (80,'Mutton', 'V',80,'A' ,'ANNA' , 'Mutton');
INSERT INTO FoodItem (ID,FoodName,Food_Type,Price,Availability,Restaurant_Name,Category_Name ) VALUES (81,'Dry Masala', 'V',80,'A' ,'ANNA' , 'Chicken');
commit;
