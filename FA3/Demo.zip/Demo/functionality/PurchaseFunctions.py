'''
Created on Aug 5, 2015

@author: Deepak_M05
'''

'''
This is a dummy module. This has to be replaced by another programmer's code
'''

def purchase_product(product_id):
    #dummy Function
    print("Product purchased")