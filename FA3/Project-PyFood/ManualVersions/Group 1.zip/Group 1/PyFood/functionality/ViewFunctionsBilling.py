'''
Created on Mar 17, 2017

@author: komal.preet
'''
from database import ViewDBbilling
from classes.BillingModule4 import Billing
from validations import ValidateBilling
from classes import FoodModule


# username = FoodModule.Food.registered_user

#print(username)
'''0'''
def start_billing():
#     global username
#     check=check_for_empty()
#     
#     if check == 0:
#         print("Your cart is empty.!")
#     else:
#     guest = FoodModule.Food.is_registered_user
#     print(guest)
#     if guest == None :
#
    username = FoodModule.Food.registered_user
    print("Do you want to Bill, Cancel or Save for later? (B/C/S)")
    ans=input()
#     start_billing_ans = Billing.start_billing_ans
    if ans.upper() == "B":
        fetching_chosen_restaurant()
    elif ans.upper() == "S":
        print("Your data has been saved in the cart. Thank you and come back soon!")
    elif ans.upper() == "C":
        ViewDBbilling.db_start_billing(username)
        print("Your data has been deleted. Thank you and come back soon!")
    else:
        print("You have entered an invalid entry. Kindly chose again.")
        start_billing()
        
'''0.5
def check_for_empty():
    username = FoodModule.Food.registered_user
    check = ViewDBbilling.db_check_for_empty(username)
    if check == 0:
        return 0
    else:
        return 1
    '''
    
'''1'''
def fetching_chosen_restaurant():
#     global username
#     print(username)
#     print("Global")
#     print(FoodModule.Food.registered_user)
    
    username = FoodModule.Food.registered_user
    ViewDBbilling.db_fetching_chosen_restaurant(username)
    display_first_line()
        
'''2'''
def display_first_line():
    restaurant_name = FoodModule.Food.restaurant_name
    #print(restaurant_name)
    print("Items ordered @ ",restaurant_name)
    display_cart()
    
'''2.5'''
def display_cart():
    username = FoodModule.Food.registered_user
    ViewDBbilling.db_display_cart(username)
#     fetching_items_available()
#     checking_availability()
#     if len(Billing.items_not_available) != 0:
#         displaying_unavailable_items()
#     else:
#         dine_delivery()
    dine_delivery()

'''3
def fetching_items_available():
    ViewDBbilling.db_fetching_items_available()
    '''
        
'''4
def checking_availability():
    for foodname in Billing.food_ordered:
        
        if foodname not in Billing.food_item_list:
            Billing.items_not_available.append(foodname)
            '''
            
'''5
def displaying_unavailable_items():
    print("Following item(s) in your cart are not available:-")
    for i in Billing.items_not_available:
        print(i)
    processing_unavailable_items()
    '''
    
            
'''6
def processing_unavailable_items():
    
    from functionality import ViewFunctions
    username = FoodModule.Food.registered_user
    answer = "a"
    if len(Billing.food_ordered) == len(Billing.items_not_available):
        print("Will go to kautilya's function latter.")
        
        ViewFunctions.view_category()
    else:
        print("Do you want to continue billing without the unavailable item(s)? (Y/N)")
        answer=input()

    if answer.upper() == "Y":
        ViewDBbilling.db_processing_unavailable_items(username)
        dine_delivery()
    elif answer.upper() == "N":
        ViewFunctions.view_category()
        print("Will go to kautilya's function latter.")
    elif answer.upper() != "Y" and answer.upper()!= "N" and answer.upper() != "A":
        print("Invalid entry. Kindly enter again.")
        processing_unavailable_items()
        '''
        
'''7'''
def dine_delivery():
    print("You would like to dine-in(I) or door-delivery(D)?")
    ans=input()
    print(ans)
    updating_total_price()
    calculating_total_charge()
    display_full_cart()
    checking_discount_eligibility()
    if ans.upper() == "D":
        if_door_deliver()
    elif ans.upper() == "I":
        print("Dine-in")
        
    else:
        print("Invalid entry. Kindly enter again.")
        dine_delivery()
    displaying_total_amount()
    fetching_payment_option()
    
'''8'''
def updating_total_price():
    username = FoodModule.Food.registered_user
    ViewDBbilling.db_updating_total_price(username)
    
    
'''9'''
def display_full_cart():
    username = FoodModule.Food.registered_user
    ViewDBbilling.db_display_full_cart(username)
    
    
'''10'''
def calculating_total_charge():
    username = FoodModule.Food.registered_user
    ViewDBbilling.db_calculating_total_charge(username)
    
        
'''11'''
def checking_discount_eligibility():
    is_registered_user = FoodModule.Food.is_registered_user
    if is_registered_user == True:
        discount=0.05*Billing.total_charge
    else:
        discount = 0
    print("Discount = ",discount)
    Billing.total_charge=Billing.total_charge-discount
    
'''12'''
def if_door_deliver():
    delivery_charges = ViewDBbilling.db_if_door_deliver()
    Billing.total_charge+=delivery_charges
    print("Delivery charges = ",delivery_charges)
        
'''13'''
def displaying_total_amount():
    print("Total charge = ",Billing.total_charge)
    
'''14'''
def fetching_payment_option():
    print("Payment Option (cash/card): ")
    ans=input()
    if ans.lower() == "cash":
        if_cash()
    elif ans.lower() == "card":
        if_card()
    else:
        print("Invalid entry. Kindly enter again")
        fetching_payment_option()

'''15'''
def if_cash():
    username = FoodModule.Food.registered_user
    print("Amount paid successfully !")
#     ViewDBbilling.db_deleting_after_payment(username)
    ViewDBbilling.db_updating_transection_table(username)
    ViewDBbilling.db_deleting_after_payment(username)
    take_feedback()
    
'''16'''
def if_card():
    username = FoodModule.Food.registered_user
    print("Enter card number : ")
    Billing.card_number=input()
    print("Enter cvv number : ")
    Billing.cvv_number=input()
    print("Enter expiry date : ")
    Billing.expiry_date=input()
    print("Enter the name on card : ")
    Billing.name_on_card=input()
    print("Enter grid_card_number(H-I-K) : ")
    Billing.grid_card_number=input()
    if validate_card() == True:
        if Billing.card_number.startswith("4"):
            print("Card is valid! Type Visa")
            print("Amount paid successfully !")
        elif Billing.card_number.startswith("5"):
            print("Card is valid! Type MasterCard")
            print("Amount paid successfully !")
        elif Billing.card_number.startswith("6"):
            print("Card is valid! Type Rupay")
            print("Amount paid successfully !")
        else:
            print("Card is valid! Type 'others'")
            print("Amount paid successfully !")
    else:
        print("Invalid card. Please enter card details again.")
        if_card()
    ViewDBbilling.db_updating_transection_table(username)
    ViewDBbilling.db_deleting_after_payment(username)
    take_feedback()
    
'''17'''
def validate_card():
    card_number = Billing.card_number
    cvv_number = Billing.cvv_number
    card_name = Billing.name_on_card
    expiry_date = Billing.expiry_date
    
    card_number_validate = ValidateBilling.ValidateCardNumber(card_number)
    cvv_number_validate = ValidateBilling.ValidatecvvNumber(cvv_number)
    card_name_validate = ValidateBilling.ValidateCardName(card_name)
    expiry_date_validate = ValidateBilling.validateExpiryDate(expiry_date)
    
    if card_number_validate and cvv_number_validate and card_name_validate and expiry_date_validate:
        return True
    else:
        return False
    

'''18'''
def take_feedback():
    print("Provide Rating: ")                     
#     ratings=input()
    Billing.rating_ans=float(input())
    ViewDBbilling.db_update_rating(Billing.rating_ans)
    
    print("Did you like the service? (Y/N)")
    Billing.like_ans=input()
    
    if Billing.like_ans.upper() == "Y":
        ViewDBbilling.db_take_feedback_first()
        
        
    if Billing.like_ans.upper() == "N":
        ViewDBbilling.db_take_feedback_second()
    print("Thank you for you feedback. Have a nice day!")
