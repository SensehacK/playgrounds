'''
Created on Mar 17, 2017

@author: gaurav.sainger
'''
print("You are not eligible for any discounts")
def guest_user():
    city = input("Enter your city:")
    area = input("Enter your area:")