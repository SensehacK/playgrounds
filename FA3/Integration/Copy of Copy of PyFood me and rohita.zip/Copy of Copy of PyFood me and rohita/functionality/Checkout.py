'''
Created on Mar 15, 2017

@author: kautilya.save
'''



def checkout(username):
    
    print("Checkout in progress")
    
    print("Please Select from the below menu ")
    
    
    checkout_choice = input("Do you wish to proceed for billing or cancelling any item or Save for later ? (Y/C/S) " )
    
    print("Your Selected Choice is ")
    print(checkout_choice)
    
    if checkout_choice == 'Y': 
        print("Hello")

    elif checkout_choice == 'C' :
        
        pass
    
    elif checkout_choice == 'S' :
        pass
    
    

def checkout_Yes(username):
    pass
    

def checkout_Cancel(username):
    pass
    
    
def checkout_Save(username):
    pass

    print("Item Saved Successfully!!!")
    
