'''
Created on Mar 17, 2017

@author: kautilya.save
'''


def display_most_rated_hotel():
    pass

    

def display_most_ordered_transactions_user():
    pass


def display_highest_booked_hotel_by_city():
    pass
    