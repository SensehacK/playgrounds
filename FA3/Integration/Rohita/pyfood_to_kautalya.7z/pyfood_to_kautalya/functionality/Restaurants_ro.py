'''
Created on Mar 16, 2017

@author: venkata.goparaju
'''
def restaurants():
    print("Go to gaurav's module")