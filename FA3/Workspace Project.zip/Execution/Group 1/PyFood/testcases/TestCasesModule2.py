'''
Created on Mar 20, 2017

@author: gaurav.sainger
'''



from validations import Validate
from exceptions import CustomException2

''' positive'''

try:
    city="DELHI"
    area="CP"
    output=Validate.validate_search_category(city,area)
    print("passsed")
except CustomException2.Invalidcityareaname as e:
    print(e)
   
try:
    city="DELHI"
    area="CP"
    rating_lower=2
    rating_upper=10
    output=Validate.validate_search_as_rating(city,area,rating_lower,rating_upper)
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e)
    
try:
    city="DELHI"
    area="CP"
    output=Validate.validate_search_as_likes(city,area)
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e)

try:
    city="DELHI"
    area="CP"
    output=Validate.validate_search_as_dislikes(city,area)
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e)

try:
    city="DELHI"
    area="CP"
    type="N"
    output=Validate.validate_search_as_type(city,area,type)
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e) 

try:
    city="DELHI"
    area="CP"
    rating_lower=2
    rating_upper=10
    output=Validate.validate_search_as_rating_dislikes(city,area,rating_lower,rating_upper)
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e)
    
try:
    city="DELHI"
    area="CP"
    rating_lower=2
    rating_upper=10
    output=Validate.validate_search_as_rating_likes(city,area,rating_lower,rating_upper)
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e)

try:
    city="DELHI"
    area="CP"
    rating_lower=2
    rating_upper=10
    type="N"
    output=Validate.validate_search_as_rating_type(city,area,rating_lower,rating_upper,type)
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e)
    
try:
    city="DELHI"
    area="CP"
    rating_lower=2
    rating_upper=10
    type="N"
    output=Validate.validate_search_as_rating_dislike_type(city,area,rating_lower,rating_upper,type)
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e) 

try:
    city="DELHI"
    area="CP"
    rating_lower=2
    rating_upper=10
    type="N"
    output=Validate.validate_search_as_all(city,area,rating_lower,rating_upper,type)
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e)
    
try:
    
    output=Validate.validate_highest_rated()
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e)                
                       
    

try:
    city="DELHI"
    
    output=Validate.validate_city_wise_highest_booked(city)
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e)                                   
                                 
                                    
                       
    
    
    
    
'''negative'''
    
try:
    city="DELHI"
    area="Ct"
    
    output=Validate.validate_search_category(city,area)
    print("invalid")
except CustomException2.Invalidcityareaname as e:
    print(e,end=' ')
    print("-failed")    

try:
    city="DELHI"
    area="Ct"
    rating_lower=2
    rating_upper=10
    output=Validate.validate_search_as_rating(city,area,rating_lower,rating_upper)
    print("invalid")
except CustomException2.Invalidfilter as e:
    print(e,end=' ')
    print("-failed")

try:
    city="DELHI"
    area="Cd"
    output=Validate.validate_search_as_likes(city,area)
    print("invalid")
except CustomException2.Invalidfilter as e:
    print(e,end=' ')
    print("-failed")
    
try:
    city="DELHI"
    area="Cd"
    output=Validate.validate_search_as_dislikes(city,area)
    print("invalid")
except CustomException2.Invalidfilter as e:
    print(e,end=' ')
    print("-failed")
    
try:
    city="DELHI"
    area="Cd"
    output=Validate.validate_search_as_type(city,area,type)
    print("invalid")
except CustomException2.Invalidfilter as e:
    print(e,end=' ')
    print("-failed")

try:
    city="DLHI"
    area="CP"
    rating_lower=2
    rating_upper=10
    output=Validate.validate_search_as_type(city,area,type)
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e,end=' ')
    print("-failed")

try:
    city="DLHI"
    area="CP"
    rating_lower=2
    rating_upper=10
    type="N"
    output=Validate.validate_search_as_rating_likes(city,area,rating_lower,rating_upper)
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e,end=' ')
    print("-failed")
    
try:
    city="DLHI"
    area="CP"
    rating_lower=2
    rating_upper=10
    output=Validate.validate_search_as_rating_type(city,area,rating_lower,rating_upper,type)
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e,end=' ')
    print("-failed")

try:
    city="DLHI"
    area="CP"
    rating_lower=2
    rating_upper=10
    type="N"
    output=Validate.validate_search_as_rating_type(city,area,rating_lower,rating_upper,type)
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e,end=' ')
    print("-failed") 

try:
    city="DLHI"
    area="CP"
    rating_lower=2
    rating_upper=10
    type="N"
    output=Validate.validate_search_as_all(city,area,rating_lower,rating_upper,type)
    print("passsed")
except CustomException2.Invalidfilter as e:
    print(e,end=' ')
    print("-failed") 



try:
    city="DEHI"
    
    output=Validate.validate_city_wise_highest_booked(city)
    print("INVLAID")
except CustomException2.Invalidfilter as e:
    print(e,end=' ')
    print("-failed")    
    

                                                      
                                 
                                 
    
               
                                              
                
                            
