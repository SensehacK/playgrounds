'''
Created on Mar 16, 2017

@author: venkata.goparaju
'''
def empty_validation(input_data):
    a = input("username:")
    if (len(a) == 0):
        print("Username cannot be empty")
        
empty_validation("rohita")
