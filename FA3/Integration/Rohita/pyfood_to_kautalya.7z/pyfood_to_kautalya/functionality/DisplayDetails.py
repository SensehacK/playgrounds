'''
Created on Mar 17, 2017

@author: kautilya.save
'''

from classes import FoodModule

def display_most_rated_hotel():
    pass
FoodModule.Food.registered_user = 'Rohita'
    

def display_most_ordered_transactions_user():
    pass


def display_highest_booked_hotel_by_city():
    pass
    