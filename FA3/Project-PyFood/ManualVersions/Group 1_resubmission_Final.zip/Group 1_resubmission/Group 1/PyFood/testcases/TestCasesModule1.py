'''
Created on Mar 20, 2017

@author: venkata.goparaju
'''
import pytest

from validations.All_validations import validate_phone_number,validate_email,validate_password,validate

''' positive testcases'''

def test_validate_password():
    valid_password = 'rohi@234'
    expectedoutput = True
    actualoutput = validate_password(valid_password)
    assert actualoutput == expectedoutput

def test_validate_email():
    valid_email = 'gvsrohita@gmail.com'
    expectedoutput = True
    actualoutput = validate_email(valid_email)
    assert actualoutput == expectedoutput
    
def test_validate_phonenumber():
    valid_phone_number = '9491301356'
    expectedoutput = True
    actualoutput = validate_phone_number(valid_phone_number)
    assert actualoutput == expectedoutput
    
def test_validate():
    valid_length = 'Rohita'
    expectedoutput = True
    actualoutput = validate(valid_length)
    assert actualoutput == expectedoutput
    
'''negative testcases'''
def test_validate_password1():
    valid_password = 'rohita'
    expectedoutput = False
    actualoutput = validate_password(valid_password)
    assert actualoutput == expectedoutput

def test_validate_email1():
    valid_email = 'gvsrohita@nael'
    expectedoutput = False
    actualoutput = validate_email(valid_email)
    assert actualoutput == expectedoutput
    
def test_validate_phonenumber1():
    valid_phone_number = '12345'
    expectedoutput = False
    actualoutput = validate_phone_number(valid_phone_number)
    assert actualoutput == expectedoutput
    
def test_validate1():
    valid_length = ''
    expectedoutput = False
    actualoutput = validate(valid_length)
    assert actualoutput == expectedoutput
