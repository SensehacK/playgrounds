'''
Created on Mar 20, 2017

@author: gaurav.sainger
'''
from validations.ValidateBilling import ValidateCardNumber,ValidatecvvNumber,ValidateCardName,validateExpiryDate

''' positive testcases'''

def test_validate_cardnumber():
    valid_cardnumber = '1234-1234-1234-1234'
    expectedoutput = True
    actualoutput = ValidateCardNumber(valid_cardnumber)
    assert actualoutput == expectedoutput
    
def test_ValidatecvvNumber():
    valid_cvv = '123'
    expectedoutput = True
    actualoutput = ValidatecvvNumber(valid_cvv)
    assert actualoutput == expectedoutput
    
def test_ValidateCardName():
    valid_cardname = 'komal'
    expectedoutput = True
    actualoutput = ValidateCardName(valid_cardname)
    assert actualoutput == expectedoutput
    
def test_validateExpiryDate():
    valid_expirydate = '12/23'
    expectedoutput = True
    actualoutput = validateExpiryDate(valid_expirydate)
    assert actualoutput == expectedoutput
    

''' negative testcases'''

def test_validate_cardnumber_negative():
    valid_cardnumber = '12s4-1f34-1234-1234'
    expectedoutput = False
    actualoutput = ValidateCardNumber(valid_cardnumber)
    assert actualoutput == expectedoutput
    
def test_ValidatecvvNumber_negative():
    valid_cvv = '123e'
    expectedoutput = False
    actualoutput = ValidatecvvNumber(valid_cvv)
    assert actualoutput == expectedoutput
    
def test_ValidateCardName_negative():
    valid_cardname = 'komal1'
    expectedoutput = False
    actualoutput = ValidateCardName(valid_cardname)
    assert actualoutput == expectedoutput
    
def test_validateExpiryDate_negative():
    valid_expirydate = '12.23'
    expectedoutput = False
    actualoutput = validateExpiryDate(valid_expirydate)
    assert actualoutput == expectedoutput
    

