'''
Created on Mar 18, 2017

@author: kautilya.save
'''
'''
Created on Mar 16, 2017

@author: komal.preet
'''
import cx_Oracle
from shutil import chown
from classes import FoodModule
con = cx_Oracle.Connection('t753498/t753498@10.123.79.57/georli02')
cur = cx_Oracle.Cursor(con)

class Billing:
    username = FoodModule.Food.registered_user
    is_registered_user = True
    
    def __init__(self):
        self.__chosen_restaurant = ""
        self.food_ordered = []
        self.food_item_list = []
        self.items_not_available = []
        self.__total_charge = 0
        self.__discount = 0
        self.__ans = ""
        self.__payment_ans = ""
        self.__rating_ans = 0
        self.__like_ans = ""
        self.__updated_likes = 0
        self.__updated_dislikes = 0
        self.__card_number = ""
        self.__cvv_number = 0
        self.__expiry_date = ""
        self.__name_on_card = ""
        self.__grid_card_number = ""
        self.__start_billing_ans = ""

    

    def get_chosen_restaurant(self):
        return self.__chosen_restaurant
    def get_food_ordered(self):
        return self.food_ordered
    def get_food_item_list(self):
        return self.food_item_list
    def get_items_not_available(self):
        return self.items_not_available
    def get_total_charge(self):
        return self.__total_charge
    def get_discount(self):
        return self.__discount
    def get_ans(self):
        return self.__ans
    def get_payment_ans(self):
        return self.__payment_ans
    def get_rating_ans(self):
        return self.__rating_ans
    def get_like_ans(self):
        return self.__like_ans
    def get_updated_likes(self):
        return self.__updated_likes
    def get_updated_dislikes(self):
        return self.__updated_dislikes
    def get_card_number(self):
        return self.__card_number
    def get_cvv_number(self):
        return self.__cvv_number
    def get_expiry_date(self):
        return self.__expiry_date
    def get_name_on_card(self):
        return self.__name_on_card
    def get_grid_card_number(self):
        return self.__grid_card_number
    def get_start_billing_ans(self):
        return self.__start_billing_ans


    def set_chosen_restaurant(self, value):
        self.__chosen_restaurant = value
    def set_food_ordered(self, value):
        self.food_ordered = value
    def set_food_item_list(self, value):
        self.food_item_list = value
    def set_items_not_available(self, value):
        self.items_not_available = value
    def set_total_charge(self, value):
        self.__total_charge = value
    def set_discount(self, value):
        self.__discount = value
    def set_ans(self, value):
        self.__ans = value
    def set_payment_ans(self, value):
        self.__payment_ans = value
    def set_rating_ans(self, value):
        self.__rating_ans = value
    def set_like_ans(self, value):
        self.__like_ans = value
    def set_updated_likes(self, value):
        self.__updated_likes = value
    def set_updated_dislikes(self, value):
        self.__updated_dislikes = value
    def set_card_number(self, value):
        self.__card_number = value
    def set_cvv_number(self, value):
        self.__cvv_number = value
    def set_expiry_date(self, value):
        self.__expiry_date = value
    def set_name_on_card(self, value):
        self.__name_on_card = value
    def set_grid_card_number(self, value):
        self.__grid_card_number = value
    def set_start_billing_ans(self, value):
        self.__start_billing_ans = value

    '''0'''
    def start_billing(self):
        print("Do you want to Bill, Cancel or Save for latter? (B/C/S)")
        self.set_start_billing_ans(input())
        if self.get_start_billing_ans().upper() == "B":
            self.check_for_empty()
        elif self.get_start_billing_ans().upper() == "S":
            print("Your data has been saved in the cart. Thank you and come back soon!")
        elif self.get_start_billing_ans().upper() == "C":
            cur.execute("delete from CheckoutCart where username = :username",{"username":Billing.username})
            print("Your data has been deleted. Thank you and come back soon!")
        else:
            print("You have entered an invalid entry. Kindly chose again.")
            self.start_billing()
            
    '''0.5'''
    def check_for_empty(self):
        check = 0
        cur.execute("select quantity from CheckoutCart where username = :username",{"username":Billing.username})
        for i in cur:
            check = i
        if check == 0:
            print("Your cart is empty.!")
            print("Will go back to main menu")
        else:
            self.fetching_chosen_restaurant()
        
    '''1'''
    def fetching_chosen_restaurant(self):
        cur.execute("select restaurant_name from CheckoutCart where username = :username",{"username":Billing.username})
        for restaurant_name in cur:
            self.set_chosen_restaurant(restaurant_name[0])
        self.display_first_line()
            
    '''2'''
    def display_first_line(self):
        print("Items ordered @ ",self.get_chosen_restaurant())
        self.display_cart()
        
    '''2.5'''
    def display_cart(self):
        cur.execute("select foodname,quantity from CheckoutCart where username = :username",{"username":Billing.username})
        print()
        print("[ITEM NAME]  [QUANTITY]")
        for foodname,quantity in cur:
            print(foodname,"          ",quantity)
            self.food_ordered.append(foodname)
        self.fetching_items_available()
        self.checking_availability()
        if len(self.items_not_available) != 0:
            self.displaying_unavailable_items()
        else:
            self.dine_delivery()
    
    '''3'''
    def fetching_items_available(self):
        cur.execute("select foodname from fooditem where restaurant_name=:restaurant_name",{"restaurant_name":self.get_chosen_restaurant()})
        for foodname in cur:
            self.food_item_list.append(foodname[0])
            
    '''4'''
    def checking_availability(self):
        for foodname in self.food_ordered:
            if foodname not in self.food_item_list:
                self.items_not_available.append(foodname)
                
    '''5'''
    def displaying_unavailable_items(self):
        print("Following item(s) in your cart are not available:-")
        for i in self.items_not_available:
            print(i)
        self.processing_unavailable_items()
        
                
    '''6'''
    def processing_unavailable_items(self):
        answer = ""
        if len(self.food_ordered) == len(self.items_not_available):
            print("Will go to kautilya's function latter.")
        else:
            print("Do you want to continue billing without the unavailable item(s)? (Y/N)")
            answer=input()

        if answer == "Y":
            for i in self.items_not_available:
                cur.execute("delete from checkoutcart where username = :username and foodname = :foodname",{"username":Billing.username,"foodname":i})
                self.dine_delivery()
        elif answer == "N":
            print("Will go to kautilya's function latter.")
            
    '''7'''
    def dine_delivery(self):
        print("You would like to dine-in(I) or door-delivery(D)?")
        self.set_ans(input())
        self.updating_total_price()
        self.calculating_total_charge()
        self.display_full_cart()
        self.checking_discount_eligibility()
        if self.get_ans() == "D":
            self.if_door_deliver()
        self.displaying_total_amount()
        self.fetching_payment_option()
        
    '''8'''
    def updating_total_price(self):
        cur.execute("update checkoutcart set total_price = quantity * price where username = :username",{"username":Billing.username})
        
    '''9'''
    def display_full_cart(self):
        cur.execute("select foodname,quantity,price,total_price from CheckoutCart where username = :username",{"username":Billing.username})
        print()
        print("[ITEM NAME]  [QUANTITY] [PRICE] [TOTAL_PRICE]")
        for foodname,quantity,price,total_price in cur:
            print(foodname,"         ",quantity,"       ",price,"    ",total_price)
        print()
        
    '''10'''
    def calculating_total_charge(self):
        cur.execute("select sum(total_price) from CheckoutCart where username = :username group by username",{"username":Billing.username})
        for i in cur:
            self.set_total_charge(i[0])
            
    '''11'''
    def checking_discount_eligibility(self):
        if Billing.is_registered_user == True:
            self.set_discount(0.05*self.get_total_charge())
        else:
            self.set_discount(0)
        print("Discount = ",self.get_discount())
        self.set_total_charge(self.get_total_charge()-self.get_discount())
        
    '''12'''
    def if_door_deliver(self):
        delivery_charges = 0   
        cur.execute("select DOOR_DELIVERY_CHARGES from Restaurants where RESTAURANTNAME=:restaurantname",{"restaurantname":self.get_chosen_restaurant()})
        for j in cur:
            delivery_charges = j[0]
    
        self.set_total_charge(self.get_total_charge()+delivery_charges)
        print("Delivery charges = ",delivery_charges)
            
    '''13'''
    def displaying_total_amount(self):
        print("Total charge = ",self.get_total_charge())
        
    '''14'''
    def fetching_payment_option(self):
        print("Payment Option (cash/card): ")
        self.set_payment_ans(input())
        if self.get_payment_ans().lower() == "cash":
            self.if_cash()
        elif self.get_payment_ans().lower() == "card":
            self.if_card()
    
    '''15'''
    def if_cash(self):
        print("Amount paid successfully !")
        self.take_feedback()
        
    '''16'''
    def if_card(self):
        print("Enter card number : ")
        self.set_card_number(input())
        print("Enter cvv number : ")
        self.set_cvv_number(input())
        print("Enter expiry date : ")
        self.set_expiry_date(input())
        print("Enter the name on card : ")
        self.set_name_on_card(input())
        print("Enter grid_card_number(H-I-K) : ")
        self.set_grid_card_number(input())
        if self.validate_card() == True:
            if self.get_card_number().startswith("4"):
                print("Card is valid! Type Visa")
            elif self.get_card_number().startswith("5"):
                print("Card is valid! Type MasterCard")
            elif self.get_card_number().startswith("6"):
                print("Card is valid! Type Rupay")
            else:
                print("Card is valid! Type 'others'")
        else:
            print("Invalid card. Please enter card details again.")
            self.if_card()
        self.take_feedback()
        
    '''17'''
    def validate_card(self):
        card_number = self.get_card_number()
        cvv_number_str = str(self.get_cvv_number())
        name = self.get_name_on_card()
        card_number_final = ""
        
        card_validate = True
        cvv_validate = True
        name_validate = True
        
        for i in range(0,len(card_number)):
            if i!=4 and i!=9 and i!=14:
                card_number_final = card_number_final + card_number[i]    
        if card_number_final.isdigit():
            card_validate = True
        else:
            card_validate = False
        
        if cvv_number_str.isdigit():
            cvv_validate = True
        else:
            cvv_validate = False
            
        if name.isalpha():
            name_validate = True
        else:
            name_validate = False
                
                
        if len(card_number_final) == 16 and len(self.get_cvv_number()) == 3 and cvv_validate == True and card_validate == True and name_validate == True:
            return True
        else:
            return False
        
    
    '''18'''
    def take_feedback(self):
        print("Provide Rating: ")
        self.set_rating_ans(input())
        '''***** update rating in table ******'''
        
        print("Did you like the service? (Y/N)")
        self.set_like_ans(input())
        
        if self.get_like_ans().upper() == "Y":
            cur.execute("select likes from Restaurants where RESTAURANTNAME=:restaurantname",{"restaurantname":self.get_chosen_restaurant()})
            for i in cur:
                self.set_updated_likes(i[0]+1)
            cur.execute("update Restaurants set likes =:updated_likes where RESTAURANTNAME=:restaurantname",{"restaurantname":self.get_chosen_restaurant(),"updated_likes":self.get_updated_likes()})
            
        if self.get_like_ans().upper() == "N":
            cur.execute("select dislikes from Restaurants where RESTAURANTNAME=:restaurantname",{"restaurantname":self.get_chosen_restaurant()})
            for i in cur:
                self.set_updated_dislikes(i[0]+1)
            cur.execute("update Restaurants set dislikes =:updated_dislikes where RESTAURANTNAME=:restaurantname",{"restaurantname":self.get_chosen_restaurant(),"updated_dislikes":self.get_updated_dislikes()})
    
#         print("Thank you for you feedback. Have a nice day!")

    

def start_temp():
    obj = Billing()
    obj.start_billing()
# obj.fetching_chosen_restaurant()
# obj.display_first_line()
# obj.display_cart()
# obj.fetching_items_available()
# obj.checking_availability()
# obj.displaying_unavailable_items()
# obj.processing_unavailable_items()
# obj.dine_delivery()
# obj.updating_total_price()
# obj.display_full_cart()
# obj.calculating_total_charge()
# obj.checking_discount_eligibility()
# obj.if_door_deliver()
# obj.displaying_total_amount()
# obj.fetching_payment_option()
# obj.if_cash()
# obj.if_card()
# obj.take_feedback()
